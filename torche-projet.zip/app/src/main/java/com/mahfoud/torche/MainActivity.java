package com.mahfoud.torche;

import android.Manifest;
import android.app.Activity;
import android.content.pm.PackageManager;
import android.hardware.camera2.CameraCharacteristics;
import android.hardware.camera2.CameraManager;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;

public class MainActivity extends Activity {

    private WebView web;
    private Torch torch;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

        if (Build.VERSION.SDK_INT >= 23
                && checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.CAMERA}, 1);
        }

        web = new WebView(this);
        web.setBackgroundColor(0xFF000000);
        setContentView(web);

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);

        web.setWebChromeClient(new WebChromeClient());
        torch = new Torch();
        web.addJavascriptInterface(torch, "AndroidTorch");
        web.loadUrl("file:///android_asset/index.html");
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) {
            web.setSystemUiVisibility(View.SYSTEM_UI_FLAG_FULLSCREEN
                    | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                    | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                    | View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                    | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                    | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION);
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        torch.off();
        web.onPause();
    }

    @Override
    protected void onResume() {
        super.onResume();
        web.onResume();
    }

    @Override
    protected void onDestroy() {
        torch.off();
        super.onDestroy();
    }

    /** Pont JavaScript : pilotage de la vraie lampe, avec intensité réelle si le téléphone le permet. */
    public class Torch {
        private CameraManager cm;
        private String camId = null;
        private int max = 1;
        private int last = -1;

        Torch() {
            try {
                cm = (CameraManager) MainActivity.this.getSystemService(CAMERA_SERVICE);
                for (String id : cm.getCameraIdList()) {
                    CameraCharacteristics ch = cm.getCameraCharacteristics(id);
                    Boolean flash = ch.get(CameraCharacteristics.FLASH_INFO_AVAILABLE);
                    Integer facing = ch.get(CameraCharacteristics.LENS_FACING);
                    if (flash != null && flash && facing != null
                            && facing == CameraCharacteristics.LENS_FACING_BACK) {
                        camId = id;
                        if (Build.VERSION.SDK_INT >= 33) {
                            Integer m = ch.get(CameraCharacteristics.FLASH_INFO_STRENGTH_MAXIMUM_LEVEL);
                            if (m != null && m > 0) max = m;
                        }
                        break;
                    }
                }
            } catch (Exception e) {
                camId = null;
            }
        }

        @JavascriptInterface
        public boolean available() {
            return camId != null;
        }

        @JavascriptInterface
        public int maxLevel() {
            return max;
        }

        @JavascriptInterface
        public synchronized void setLevel(double lv) {
            if (camId == null) return;
            int q;
            if (lv < 0.06) {
                q = 0;
            } else if (max > 1) {
                q = (int) Math.round(lv * max);
                if (q < 1) q = 1;
                if (q > max) q = max;
            } else {
                q = 1;
            }
            if (q == last) return;
            try {
                if (q == 0) {
                    cm.setTorchMode(camId, false);
                } else if (max > 1 && Build.VERSION.SDK_INT >= 33) {
                    cm.turnOnTorchWithStrengthLevel(camId, q);
                } else {
                    cm.setTorchMode(camId, true);
                }
                last = q;
            } catch (Exception e) {
                // on réessaiera au prochain cycle
            }
        }

        public synchronized void off() {
            if (camId == null) return;
            try {
                cm.setTorchMode(camId, false);
            } catch (Exception e) {
                // ignoré
            }
            last = -1;
        }
    }
}
